document.getElementById("bookingForm").addEventListener("submit", function(e) {
  e.preventDefault();
  let msg = `Booking Request:%0AName: ${name.value}%0APhone: ${phone.value}`;
  window.open(`https://wa.me/919167101212?text=${msg}`, "_blank");
});
